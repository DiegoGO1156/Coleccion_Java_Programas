package org.diegogarcia.models;

import org.diegogarcia.controllers.IVehiculo;

public class Barco extends Vehiculo implements IVehiculo{
    private String tipovela;
    
    public Barco(){
        super();
    }
    public Barco(String color, int modelo, double longitud, String tipovela){
        super(color, modelo, longitud);
        this.tipovela = tipovela;
    }
    public String getTipovela(){
        return tipovela;
    }
    public void setTitpovela(String tipovela){
        this.tipovela = tipovela;
    }
    @Override
    public void saludo(){
        System.out.println("--------------------------------------------------");
        System.out.println("HOLA SOY UN BARCO Y MI TIPO DE VELA ES "+ tipovela);
        System.out.println("COLOR: "+ getColor());
        System.out.println("LONGITUD: "+ getLongitud());
        System.out.println("MODELO: "+ getModelo());
        System.out.println("--------------------------------------------------");
    }
}
