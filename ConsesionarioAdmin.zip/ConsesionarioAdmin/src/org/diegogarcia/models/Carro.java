package org.diegogarcia.models;

import org.diegogarcia.controllers.IVehiculo;

public class Carro extends Vehiculo implements IVehiculo {
    private String terreno;

    public Carro(){
        super();
    }
    public Carro(String color, int modelo, double longitud, String terreno ){
        super(color, modelo, longitud);
        this.terreno = terreno;
    }
    public String getTerreno(){
        return terreno;
    }
    public void setTerreno(String terreno){
        this.terreno = terreno;
    }


    @Override 
    public void saludo(){
        System.out.println("--------------------------------------------------");
        System.out.println("HOLA SOY UN CARRO Y EL TERRENO ESPECIALIZADO QUE TENGO ES " + terreno);
        System.out.println("COLOR: "+ getColor());
        System.out.println("LONGITUD: "+ getLongitud());
        System.out.println("MODELO: "+ getModelo());
        System.out.println("--------------------------------------------------");
    }
    
}
