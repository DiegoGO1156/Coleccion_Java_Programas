package org.diegogarcia.models;

import org.diegogarcia.controllers.IVehiculo;

public class Moto extends Vehiculo implements IVehiculo {
    private String transision;

    public Moto(){
        super();
    }
    public Moto(String color, int modelo, double longitud, String transision){
        super(color,modelo,longitud);
        this.transision = transision;
    }
    public String getTransision(){
        return transision;
    }
    public void setTransision(String transision){
        this.transision = transision;
    }


     @Override
     public void saludo(){
        System.out.println("--------------------------------------------------");
        System.out.println("HOLA SOY UNA MOTO Y MI TRANSISION ES "+ transision);
        System.out.println("COLOR: "+ getColor());
        System.out.println("LONGITUD: "+ getLongitud());
        System.out.println("MODELO: "+ getModelo());
        System.out.println("--------------------------------------------------");
     }
    
}
