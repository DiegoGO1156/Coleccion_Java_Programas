package org.diegogarcia.models;

public class Vehiculo {
    private String color;
    private int modelo;
    private double longitud;

    public Vehiculo(){

    }
    public Vehiculo(String color, int modelo,double longitud){
        this.color = color;
        this.modelo = modelo;
        this.longitud = longitud;
    }
    public String getColor(){
        return color;
    }
    public void setColor(String color){
        this.color = color;
    }
    public int getModelo(){
        return modelo;
    }
    public void setModelo(int modelo){
        this.modelo = modelo;
    }
    public double getLongitud(){
        return longitud;
    }
    public void setLongitud(double longitud){
        this.longitud = longitud;
    }


    
}
