package org.diegogarcia.controllers;

import java.util.ArrayList;
import java.util.Scanner;

import org.diegogarcia.models.Barco;
import org.diegogarcia.models.Moto;
import org.diegogarcia.models.Carro;

public class VehiculoController {
     ArrayList<IVehiculo> listaVehiculos = new ArrayList<>();
        Scanner sc = new Scanner(System.in);
    public void agregar(){
        try {
            System.out.println("--------------------------------------------------");
            System.out.println("Seleccione el tipo de Vehiculo");
            System.out.println("1. Moto");
            System.out.println("2. Barco");
            System.out.println("3. Carro");
            int menu = sc.nextInt();
            sc.nextLine();
            System.out.println("--------------------------------------------------");
            System.out.println("Ingrese el color del Vehiculo");
            String color = sc.nextLine();
            System.out.println("--------------------------------------------------");
            System.out.println("Ingrese el Modelo del Vehiculo");
            int modelo = sc.nextInt();
            sc.nextLine();
            System.out.println("--------------------------------------------------");
            System.out.println("Ingrese la longitud del Vehiculo");
            double longi = sc.nextDouble();
            sc.nextLine();

            if(menu == 1){
                System.out.println("--------------------------------------------------");
                System.out.println("Ingrese el tipo de Transision de la moto");
                String transision = sc.nextLine();
                listaVehiculos.add(new Moto(color, modelo, longi, transision));
            }else if(menu == 2 ){
                System.out.println("--------------------------------------------------");
                System.out.println("Ingrese el tipo de vela del barco");
                String vela = sc.nextLine();
                listaVehiculos.add(new Barco(color, modelo, longi, vela));
            }else if( menu == 3){
                System.out.println("--------------------------------------------------");
                System.out.println("Ingres el tipo de terreno especializado para el carro");
                String terreno = sc.nextLine();
                listaVehiculos.add(new Carro(color, modelo, longi, terreno));
            }
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("----------------------------------------------");
            System.out.println("EL DATO QUE FUE INTRODUCIDO ES EL INCORRECTO");
            System.out.println("----------------------------------------------");
            sc.nextLine();
        }
        
    }
    public void Mostrar(){
        System.out.println("Seleccione el tipo de vehiculo que quiere mostrar");
        
        for(IVehiculo vehiculo : listaVehiculos){
            vehiculo.saludo();
        }
    }
    
}
