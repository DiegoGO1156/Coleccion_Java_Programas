package org.diegogarcia.controllers;

public interface IVehiculo {
    public void saludo();
    
}
