package org.diegogarcia.system;

import org.diegogarcia.views.Menu;

public class Main {
    public static void main(String[] args) throws Exception {
        Menu menu = new Menu();
        menu.Mostrarmenu();

    }
}
