package org.diegogarcia.views;

import java.util.Scanner;
import org.diegogarcia.controllers.VehiculoController;

public class Menu {

    Scanner sc = new Scanner(System.in);
    boolean a = true;
    int menu;
    VehiculoController controller = new VehiculoController();

    public void Mostrarmenu(){
        try {
            while(a){
            System.out.println("Seleccione una opcion");
            System.out.println("1. Agregar");
            System.out.println("2. Mostrar");
            System.out.println("3. Cerrar Programa");
                menu = sc.nextInt();
            switch(menu){
                case 1:
                controller.agregar();
                break;
                case 2:
                controller.Mostrar();
                break;
                case 3:
                System.out.println("Adios!");
                a = false;
                break;
                default:
                System.out.println("Opcion no valida");
                break;
            }
            }
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("----------------------------------------------");
            System.out.println("EL DATO INTRODUCIDO ES INCORRECTO");
            System.out.println("----------------------------------------------");
            sc.nextLine();
        }
        
    }
    
}
