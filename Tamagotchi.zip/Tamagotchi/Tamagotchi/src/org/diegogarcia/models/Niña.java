package org.diegogarcia.models;

import org.diegogarcia.controllers.ITamagotchi;

public class Niña extends Tamagotchi implements ITamagotchi{

    private static Niña instance;

    public static Niña getInstance(){
        if(instance == null){
            instance = new Niña();
        }
        return instance;
    }

    private Niña(){
        super();
    }

    public Niña(int vida, int hambre, int inteligencia, int diversion, int genero, String nombre){
        super(vida, hambre, inteligencia, diversion, genero, nombre);

    }
    
    @Override
    public void Stadistic(){
        System.out.println("HAMBRE: "+ getHambre() + "%");
        System.out.println("INTELIGENCIA: "+ getInteligencia() +"%");
        System.out.println("DIVERSION: "+ getDiversion() + "%");
        System.out.println("VIDA: "+ getVida() + "%");
        System.out.println(getNombre());
    }
}
