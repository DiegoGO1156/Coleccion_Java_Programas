package org.diegogarcia.models;

import org.diegogarcia.controllers.ITamagotchi;

public class Niño extends Tamagotchi implements ITamagotchi {
    
    private static Niño instance;

    public static Niño getInstance(){
        if(instance == null){
            instance = new Niño();
        }
        return instance;
    }

    private Niño(){
        super();
    }
    public Niño(int vida, int hambre, int inteligencia, int diversion, int genero, String nombre){
        super(vida, hambre, inteligencia, diversion, genero, nombre);

    }

    @Override
    public void Stadistic(){
        System.out.println("HAMBRE: "+ getHambre() + "%");
        System.out.println("INTELIGENCIA: "+ getInteligencia() +"%");
        System.out.println("DIVERSION: "+ getDiversion() + "%");
        System.out.println("VIDA: "+ getVida() + "%");
        System.out.println(getNombre());
    }
}
