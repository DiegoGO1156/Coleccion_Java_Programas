package org.diegogarcia.models;

public class Tamagotchi {
    private int vida;
    private int hambre;
    private int inteligencia;
    private int diversion;
    private int genero;
    private String nombre;

    public Tamagotchi(){

    }
    public Tamagotchi(int vida, int hambre, int inteligencia, int diversion, int genero, String nombre){
        this.vida = vida;
        this.hambre = hambre;
        this.inteligencia = inteligencia;
        this.genero = genero;
        this.nombre = nombre;
    }
    public int getVida(){
        return vida;
    }
    public void setVida(int vida){
        this.vida = vida;
    }
    public int getHambre(){
        return hambre;
    }
    public void setHambre(int hambre){
        this.hambre = hambre;
    }
    public int getInteligencia(){
        return inteligencia;
    }
    public void setInteligencia(int inteligencia){
        this.inteligencia = inteligencia;
    }
    public int getDiversion(){
        return diversion; 
    }
    public void setDiversion(int diversion){
        this.diversion = diversion;
    }
    public int getGenero(){
        return genero;
    }
    public void setGenero(int genero){
        this.genero = genero;
    }
    public String getNombre(){
        return nombre;
    }
    public void setNombre(String nombre){
        this.nombre = nombre;
    }
}
