package org.diegogarcia.views;
import java.util.Scanner;
import org.diegogarcia.controllers.ControllerTamago;

public class Menu {
    private static Menu instance;


    private Menu(){

    }
    public static Menu getInstance(){
        if(instance == null){
            instance = new Menu();
        }
        return instance;
    }

    public void Menu(){
        int z = 1;
        Scanner s = new Scanner(System.in);
        try {
            ControllerTamago controller = ControllerTamago.getInstance(); 
            controller.CrearPersonaje();
            while(z != 0){
                controller.Mostrardibujo();
                System.out.println("SELECCIONE UNA OPCION");
                System.out.println("1. JUGAR");
                System.out.println("2. ESTUDIAR");
                System.out.println("3. ALIMENTAR");
                System.out.println("4. DORMIR");
    
                int eleccion = s.nextInt();
                switch(eleccion){
                    case 1:
                    controller.juegos();
                    break;
                    case 2:
                    controller.Estudiar();
                    break; 
                    case 3:
                    controller.alimentar();
                    break;
                    case 4:
                    controller.Dormir();
                    break;
                    default:
                    System.out.println("ESTA ELECCION NO EXISTE");
                    break;
                }
                controller.Estado();
    
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
}
