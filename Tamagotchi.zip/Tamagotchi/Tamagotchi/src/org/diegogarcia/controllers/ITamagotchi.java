package org.diegogarcia.controllers;

public interface ITamagotchi {
    public void Stadistic();
}
