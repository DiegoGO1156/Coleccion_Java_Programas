package org.diegogarcia.controllers;

import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.BufferedReader;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.Random;

import org.diegogarcia.models.Niño;
import org.diegogarcia.models.Niña;


public class ControllerTamago {
    private static ControllerTamago instance;
    Niño niño =  Niño.getInstance();
    Niña niña =  Niña.getInstance();
    ArrayList <Niño> datosniño = new ArrayList<>();
    ArrayList <Niña> datosniña = new ArrayList<>();
    Scanner x = new Scanner(System.in);
    Random random = new Random();
    static boolean genero = definirGenero();

    private ControllerTamago(){

    }

    public static ControllerTamago getInstance(){
        if(instance == null){
            instance = new ControllerTamago();
        }
        return instance;
    }

    public void CrearPersonaje(){
        try {
            
            System.out.println("....................................................................................................;?:.................     \r\n" + //
                    "...............,:,.................................................................................;SSS;................    \r\n" + //
                    ".............,**??...........................:+*,.................................................;SSSSS+,.............. \r\n" + //
                    "............,%+:*?:;++;:,..................,**+%:.,,,....................,:;++**??????????????????SSSSSSS?;:,...........\r\n" + //
                    "............:%::;S?+;*%*,..................**::%*****?;.............,:+?%SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS%*;,........\r\n" + //
                    ".........,,:+%++++;:**:,,:::::::::,,,......*?::+%;:+?*:...........:+%SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS*:...... \r\n" + //
                    ".......,??*++:???*:+%**++;;;;;;;;;++++*+;+******;:*?,...........:?SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS*,.... \r\n" + //
                    "........:**+;+*++;;;;+**,.............;%?+;:;%*%;:**+;,.......,*SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS%:... \r\n" + //
                    "..........,;+;%+:;%+++*%;..............,+***?*;:;++++??,.....,?SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS%:.. \r\n" + //
                    ".............:S*+?;...,,..................,:;%::%+:;;++.....,?SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS?,. \r\n" + //
                    "............;%++;,,:......,:,....,,.........:%*?+...........*SSSSSSSSSS%%%%????************?????%%%%%%%%??%SSSSSSSSSSS;. \r\n" + //
                    "...........,%:....:?;.....:S*+;,.,+*;:,......,+?............SSSSSSSSS?;::,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,*SSSSSSSSSS?. \r\n" + //
                    "...........;?......,+*;....*+,;+*+:;??*:.......?+,..........SSSSSSSSS+,,,,:;;;;:,,,,,,,,,,,,,,:;+***++:,,,,*SSSSSSSSSS%, \r\n" + //
                    ".....++,...+*........,+*+:.,*+..,:+*+*?*:......,+*+;:.......SSSSSSSSS+,,,?SSSSSS;,,,,,,,,,,,,,*SSSSSSS*,,,,?SSSSSSSSSS%, \r\n" + //
                    "......;*+;?%;..;,++....,;+*+;*?;;+;%+;;;;::::::,..:??,......SSSSSSSSS+,,,+?%%%?*:,,,,,,,,,,,,,:;+***+;:,,,,?SSSSSSSSSS?. \r\n" + //
                    "...;+:..:%S;...+?*%??*+;,.,:+*?%%%??*SS%%?*;;;;,.,?%;,:+;...SSSSSSSSS*,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,?SSSSSSSSSS*.\r\n" + //
                    "...,:+*++%*,...+%:,%%%?%%+..,,::;*%,.%*%??%?::,..*??*+;:,...SSSSSSSSS%+++***???????????**????????????******%SSSSSSSSSS+. \r\n" + //
                    "......,+%??:...,**,?+???S?......,:*?;**?%%S*:,...*%*..,,....?SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS;. \r\n" + //
                    ".......:?+,......;**%%S%*,.......::;**%%%?+;;:,..;%*+++;....;SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS%,. \r\n" + //
                    ".........+*+:,.....::::,..,,,+*:,;;:::::,,::::,.,;?,,.......,?SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS;.. \r\n" + //
                    "..........,:+*+;:,,.......;++;:+++,........,,:;+*+,..........,?SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS%;... \r\n" + //
                    "..............,:;++++++;;::,,,,,,,,::;;+*??%%SS%*;,...........,+%SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS%*,.... \r\n" + //
                    "....................,,,;SSS%%%%%%SSSSSSSSSSSSSSSSS%?;,..........,;?%SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS%?;,...... \r\n" + //
                    ".......................+SSSSSSSSS%%SSSSSSSSSSSSSSSSS#+.............,:+*?%%%SSSSSSSSSSSSSSSS%SSSSSSSSSSSS%%?*;:,......... \r\n" + //
                    "......................+SSSS%%?%%%?%SSSS?;*?%%%%%%%?*+,...................,,,,,,,;*SSSSS*;%;+SSSS%+:::::,,............... \r\n" + //
                    ".....................:SSSS%*%%%*?%%%+SSS+...,,,,+*%:..........................:*%SSSSSSS+,*SSSSSSS%+:...................\r\n" + //
                    ".....................*SS?%%%%?%%%?%S,;SS?...,,,*?+S**+,.....................:?SSS%SSSSS%:?SSSSSS%%SSS?:................. \r\n" + //
                    ".....................;?;;S?+?S%??S?S?;++:,,,?%**;;*??*,...................,*SSS%;,%SSSSSSSSSSSS%:,+%SSS*................ \r\n" + //
                    "........................;?%%S%%SSS%%?++++++++?%?;++%+....................,%SS?;,..,?SSSSSSSSS%*,...,;*%?,............... \r\n" + //
                    "..........................+SSSSS%S*,:;+++++++;?%**+*%:....................,;;:.......?SSS+*SSS;........,.................\r\n" + //
                    "...........................+SSSSS?,.....,,,...,:,...,...............................?SS%.;SSS:.......................... \r\n" + //
                    "............................:?%%+,..................................................*SS%.+SS%,.......................... \r\n" + //
                    "..............................,,....................................................:SS*.;SS+...........................\r\n" + //
                    "@@@%????????????????????????????????????????%@@@?@@S%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%\r\n" + //
                    "@@@:....................:::::...............:@@@?@@;.................,,::::::,.................;@@?\r\n" + //
                    "@@@:...................;@@@@@...............:@@@?@@;..............,+%#@@@@@@@#S*:..............;@@?\r\n" + //
                    "@@@:..................+@@@@@@...............:@@@?@@;.............*#@@@@@@@@@@@@@@?,............;@@?\r\n" + //
                    "@@@:................:?@@@@@@@...............:@@@?@@;.............@@@@@@@@@@@@@@@@@S,...........;@@?\r\n" + //
                    "@@@:..............:?@@@@@@@@@...............:@@@?@@;.............@@@@@?;,,,;%@@@@@@?...........;@@?\r\n" + //
                    "@@@:............*S@@@@@@@@@@@...............:@@@?@@;............:@@@@*.......*@@@@@@...........;@@?\r\n" + //
                    "@@@:............@@@@@@S@@@@@@...............:@@@?@@;............;#@@#,.......:@@@@@@...........;@@?\r\n" + //
                    "@@@:............@@@@%;,#@@@@@...............:@@@?@@;.............,,::........+@@@@@@...........;@@?\r\n" + //
                    "@@@:............@S*:..,#@@@@@...............:@@@?@@;........................,#@@@@@%...........;@@?\r\n" + //
                    "@@@:............:.....,#@@@@@...............:@@@?@@;.......................:S@@@@@#:...........;@@?\r\n" + //
                    "@@@:..................,#@@@@@...............:@@@?@@;.....................,*@@@@@@@;............;@@?\r\n" + //
                    "@@@:..................,#@@@@@...............:@@@?@@;....................+#@@@@@@S:.............;@@?\r\n" + //
                    "@@@:..................,#@@@@@...............:@@@?@@;..................:%@@@@@@@?,..............;@@?\r\n" + //
                    "@@@:..................,#@@@@@...............:@@@?@@;................,?@@@@@@@S;................;@@?\r\n" + //
                    "@@@:..................,#@@@@@...............:@@@?@@;...............+#@@@@@@#+..................;@@?\r\n" + //
                    "@@@:..................,#@@@@@...............:@@@?@@;.............,%@@@@@@@*,...................;@@?\r\n" + //
                    "@@@:..................,#@@@@@...............:@@@?@@;.............#@@@@@@%,.....................;@@?\r\n" + //
                    "@@@:..................,#@@@@@...............:@@@?@@;.............@@@@@@#++++++++++++...........;@@?\r\n" + //
                    "@@@:..................,#@@@@@...............:@@@?@@;............,@@@@@@@@@@@@@@@@@@@...........;@@?\r\n" + //
                    "@@@:..................,#@@@@@...............:@@@?@@;............?@@@@@@@@@@@@@@@@@@@...........;@@?\r\n" + //
                    "@@@:........................................:@@@?@@;...........................................;@@?\r\n" + //
                    "@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@*SS###########################################");


                    System.out.println("========================SELECCIONE UNO DE LOS 2========================");
                    System.out.println("EL PERSONAJE FEMENINO TIENE: -2 puntos menos de vida al perder un juego, y gana +2 puntos extra en inteligencia");
                    System.out.println("EL PERSONAJE MASCULINO TIENE: -2 puntos menos en el aumento de inteligencia, y gana +2 puntos extra en diversion");
                    int a = x.nextInt();
                    x.nextLine();
                    System.out.println("INGRESE EL NOMBRE DE SU MASCOTA");
                    String nombre = x.nextLine();
                    BufferedWriter writer = new BufferedWriter(new FileWriter("Stats.txt"));

                    if(a == 1){
                        datosniño.add(new Niño(100, 0, 0, 0, a, nombre));
                        writer.write(String.valueOf(datosniño.get(0).getVida()));
                        writer.write(String.valueOf(datosniño.get(0).getHambre()));
                        writer.write(String.valueOf(datosniño.get(0).getInteligencia()));
                        writer.write(String.valueOf(datosniño.get(0).getDiversion()));
                        writer.write(String.valueOf(datosniño.get(0).getGenero()));
                        writer.write(String.valueOf(datosniño.get(0).getNombre()));
                        writer.close();
                    }else if(a == 2){
                        datosniña.add(new Niña(100, 0, 0, 0, a, nombre));
                        writer.write(String.valueOf(datosniña.get(0).getVida()));
                        writer.write(String.valueOf(datosniña.get(0).getHambre()));
                        writer.write(String.valueOf(datosniña.get(0).getInteligencia()));
                        writer.write(String.valueOf(datosniña.get(0).getDiversion()));
                        writer.write(String.valueOf(datosniña.get(0).getGenero()));
                        writer.write(String.valueOf(datosniña.get(0).getNombre()));
                        writer.write(String.valueOf(datosniña.get(0).getNombre()));
                        writer.close();
                    }
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("==============================================");
            System.out.println("======EL DATO INTRODUCIDO NO ES CORRECTO======");
            System.out.println("================================================");
            x.nextLine();
        }
    }
    public static boolean definirGenero(){
        boolean hombre = false;
        boolean mujer = false;
        try {
            BufferedReader reader = new BufferedReader(new FileReader("Stats.txt"));
            String linea;

            while((linea = reader.readLine()) != null){
                int numero = Integer.parseInt(linea);
                if(numero == 1){
                    hombre = true;
                }else if(numero == 2){
                    mujer =  true;
                }
            }
            reader.close();
            if(hombre &&! mujer){
                return true;
            }else if (!hombre && mujer){
                return false;
            }
            return genero;
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("==============================================");
            System.out.println("======EL DATO INTRODUCIDO NO ES CORRECTO======");
            System.out.println("================================================");
            return genero;
        }
    }

    public void juegos(){
        try {
            System.out.println("SELECCIONE EL JUEGO AL QUE QUIERE INGRESAR");
            System.out.println("1. Piedra, Papel o Tijeras");
            System.out.println("2. Adivine el número");
            int eleccion = x.nextInt();
            x.nextLine();
            switch(eleccion){
                case 1:
                if(genero == true){
                    System.out.println("Bienvenido al juego Piedra, Papel o Tijera");
            System.out.println("Elige una opción: 1 (Piedra), 2 (Papel), 3 (Tijera)");
            int seleccion = x.nextInt();
            
            if (seleccion < 1 || eleccion > 3) {
                System.out.println("Opción inválida. Por favor, elige 1, 2 o 3.");
                return;
            }
    
            // Generar una opción aleatoria para la computadora
            int opcionComputadora = random.nextInt(3) + 1;
    
            System.out.println("La computadora eligió: " + opcionToString(opcionComputadora));
    
            if (seleccion == opcionComputadora) {
                System.out.println("Es un empate.");
            } else if ((seleccion == 1 && opcionComputadora == 3) ||
                    (seleccion == 2 && opcionComputadora == 1) ||
                    (seleccion == 3 && opcionComputadora == 2)) {
                System.out.println("¡Ganaste!");
                datosniño.get(0).setDiversion(datosniño.get(0).getDiversion() + 8);
                datosniño.get(0).setHambre(datosniño.get(0).getHambre() + 5);
            } else {
                System.out.println("Perdiste.");
                datosniño.get(0).setVida(datosniño.get(0).getVida() - 8);
                datosniño.get(0).setHambre(datosniño.get(0).getHambre() + 15);
            }
            }else if(genero == false){
                System.out.println("Bienvenido al juego Piedra, Papel o Tijera");
            System.out.println("Elige una opción: 1 (Piedra), 2 (Papel), 3 (Tijera)");
            int seleccion = x.nextInt();
            
            if (seleccion < 1 || eleccion > 3) {
                System.out.println("Opción inválida. Por favor, elige 1, 2 o 3.");
                return;
            }
    
            int opcionComputadora = random.nextInt(3) + 1;
    
            System.out.println("La computadora eligió: " + opcionToString(opcionComputadora));
    
            if (seleccion == opcionComputadora) {
                System.out.println("Es un empate.");
            } else if ((seleccion == 1 && opcionComputadora == 3) ||
                    (seleccion == 2 && opcionComputadora == 1) ||
                    (seleccion == 3 && opcionComputadora == 2)) {
                System.out.println("¡Ganaste!");
               datosniña.get(0).setDiversion(datosniña.get(0).getDiversion() + 6);
                datosniña.get(0).setHambre(datosniña.get(0).getHambre() + 5);
            } else {
                System.out.println("Perdiste.");
                niña.setVida(datosniña.get(0).getVida() - 10);
                niña.setHambre(datosniña.get(0).getHambre() + 10);
                }
            }
                break;
                case 2:
                if(genero == true){
                    System.out.println("Bienvenido al juego Adivine el número");
                    int numeroAdivinar = random.nextInt(100) + 1; // Generar número aleatorio entre 1 y 100
                    int intentosMaximos = 5;
                    int intentosRealizados = 0;
    
                    while (intentosRealizados < intentosMaximos) {
                        System.out.println("Intento " + (intentosRealizados + 1) + ": Ingrese un número entre 1 y 100: ");
                        int numeroIngresado = x.nextInt();
    
                        if (numeroIngresado == numeroAdivinar) {
                            System.out.println("¡Felicidades! Adivinaste el número.");
                            niño.setDiversion(datosniño.get(0).getDiversion()+8);
                            niño.setHambre(datosniño.get(0).getHambre()+5);
                            break;
                        } else if (numeroIngresado < numeroAdivinar) {
                            System.out.println("El número a adivinar es mayor.");
                        } else {
                            System.out.println("El número a adivinar es menor.");
                        }
    
                        intentosRealizados++;
                    }
    
                    if (intentosRealizados == intentosMaximos) {
                        System.out.println("Lo siento, has alcanzado el máximo de intentos. El número era: " + numeroAdivinar);
                        niño.setVida(datosniño.get(0).getVida()-8);
                        niño.setHambre(datosniño.get(0).getHambre()+15);
                    }
                }else if(genero == false){
                    System.out.println("Bienvenido al juego Adivine el número");
                    int numeroAdivinar = random.nextInt(100) + 1; // Generar número aleatorio entre 1 y 100
                    int intentosMaximos = 5;
                    int intentosRealizados = 0;
    
                    while (intentosRealizados < intentosMaximos) {
                        System.out.println("Intento " + (intentosRealizados + 1) + ": Ingrese un número entre 1 y 100: ");
                        int numeroIngresado = x.nextInt();
    
                        if (numeroIngresado == numeroAdivinar) {
                            System.out.println("¡Felicidades! Adivinaste el número.");
                            niña.setDiversion(datosniña.get(0).getDiversion() + 6);
                            niña.setHambre(datosniña.get(0).getHambre() + 5);;
                            break;
                        } else if (numeroIngresado < numeroAdivinar) {
                            System.out.println("El número a adivinar es mayor.");
                        } else {
                            System.out.println("El número a adivinar es menor.");
                        }
    
                        intentosRealizados++;
                    }
    
                    if (intentosRealizados == intentosMaximos) {
                        System.out.println("Lo siento, has alcanzado el máximo de intentos. El número era: " + numeroAdivinar);
                        niña.setVida(datosniña.get(0).getVida() - 10);
                        niña.setHambre(datosniña.get(0).getHambre() + 10);
                    }
                } 
    
                break;
                default: 
                System.out.println(" ");
                System.out.println("ERROR");
                System.out.println("SELECCION NO ENCONTRADA"); 
                break;    
            }
        } catch (Exception e) {
           e.printStackTrace();
           System.out.println("EL DATO REQUERIDO ES INCORRECTO");
           x.nextLine();
        }
    }
    private String opcionToString(int opcion) {
        switch (opcion) {
            case 1:
                return "Piedra";
            case 2:
                return "Papel";
            case 3:
                return "Tijera";
            default:
                return "Opción inválida";
        }
    }
    public void Dormir(){
        try {            
            System.out.println("DURMIENDO.........");
                    for (int i = 0; i < 10; i++) {
                        System.out.print("/////////////////////////////////////////////////////////////////////////\r");
                        Thread.sleep(200);
                        System.out.print("|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||\r");
                        Thread.sleep(200);
                        System.out.print("\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\r");
                        Thread.sleep(200);
                        System.out.print("-------------------------------------------------------------------------\r");
                        Thread.sleep(200);
                    }
                    System.out.println("ERROR");
                    System.out.println("SELECCION NO ENCONTRADA"); 
                    if(genero == true){
                        datosniño.get(0).setVida(datosniño.get(0).getVida()+ 20);
                    }else if(genero == false){
                        datosniña.get(0).setVida(datosniña.get(0).getVida()+20);
                    }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public static char generarOperacion() {
        char[] operaciones = {'+', '-', '*', '/'};
        Random random = new Random();
        int index = random.nextInt(operaciones.length);
        return operaciones[index];
    }
    public static int generarNumero() {
        Random random = new Random();
        return random.nextInt(20) + 1; // Números entre 1 y 20 inclusive.
    }
    public static int calcularResultado(char operacion, int num1, int num2) {
        switch (operacion) {
            case '+':
                return num1 + num2;
            case '-':
                return num1 - num2;
            case '*':
                return num1 * num2;
            default:
                return num1 / num2;
        }
     }

    public void Estudiar(){
        try {
            System.out.println("Escoja una opcion");
            System.out.println("1. Preguntas matematicas");
            System.out.println("2. Aprender acerca del usuario");
            int eleccion = x.nextInt();
            x.nextLine();
            switch(eleccion){
                case 1:
                    System.out.println("EMPEZEMOS");
                    if(genero == true){
                        int intentos = 3;
            Scanner scanner = new Scanner(System.in);
    
            while (intentos > 0) {
                char operacion = generarOperacion();
                int num1 = generarNumero();
                int num2 = generarNumero();
                int resultado = calcularResultado(operacion, num1, num2);
    
                System.out.print("¿Cuánto es " + num1 + " " + operacion + " " + num2 + "? ");
                int respuestaUsuario = scanner.nextInt();
    
                if (respuestaUsuario == resultado) {
                    System.out.println("¡Correcto! ¡Has acertado!");
                    datosniño.get(0).setHambre(datosniño.get(0).getHambre()+5);
                    datosniño.get(0).setInteligencia(datosniño.get(0).getInteligencia()+2);
                    break;
                } else {
                    intentos--;
                    if (intentos > 0) {
                        System.out.println("Respuesta incorrecta. Te quedan " + intentos + " intento(s) restante(s).");
                    } else {
                        System.out.println("Respuesta incorrecta. Has agotado tus intentos. ¡Inténtalo de nuevo!");
                        datosniño.get(0).setHambre(datosniño.get(0).getHambre()+10);
                        datosniño.get(0).setVida(datosniño.get(0).getVida()-5);
                        }
                    }
                    }
                }else if(genero == false){
                  int intentos = 3;
            Scanner scanner = new Scanner(System.in);
    
            while (intentos > 0) {
                char operacion = generarOperacion();
                int num1 = generarNumero();
                int num2 = generarNumero();
                int resultado = calcularResultado(operacion, num1, num2);
    
                System.out.print("¿Cuánto es " + num1 + " " + operacion + " " + num2 + "? ");
                int respuestaUsuario = scanner.nextInt();
    
                if (respuestaUsuario == resultado) {
                    System.out.println("¡Correcto! ¡Has acertado!");
                    datosniña.get(0).setHambre(datosniña.get(0).getHambre()+5);
                    datosniña.get(0).setInteligencia(datosniña.get(0).getInteligencia()+2);
                    break;
    
                } else {
                    intentos--;
                    if (intentos > 0) {
                        System.out.println("Respuesta incorrecta. Te quedan " + intentos + " intento(s) restante(s).");
                    } else {
                        System.out.println("Respuesta incorrecta. Has agotado tus intentos. ¡Inténtalo de nuevo!");
                        datosniña.get(0).setHambre(datosniña.get(0).getHambre()+10);
                        datosniña.get(0).setVida(datosniña.get(0).getVida()-5);
                        }
                    }
                    }  
                }
    
                break;
                case 2:
                System.out.println("ESTUDIANDO ACERCA DEL USUARIO");
    
                break;
             }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public void alimentar(){
        try {
            System.out.println("Escoja una opción de comida");
            System.out.println("                         ',,,,,,,,,,\".                      \r\n" + //
                    "                       Ii`           ^>,                    \r\n" + //
                    "                     ^<.               .>I                  \r\n" + //
                    "                    ,+                   ')                 \r\n" + //
                    "                   'j                     '?                \r\n" + //
                    "                   !\"                      f                \r\n" + //
                    "                   :!                      t                \r\n" + //
                    "                  ')u?:,   ...         ..  /                \r\n" + //
                    "                 '?.\";--tl\"\"\"` ........   <`           OPCION 1\r\n" + //
                    "                 /.` '\"\",i_-)\\      ..   \"l           -5 de hambre      \r\n" + //
                    "                '[`\"\"\"\"\"\"\"\"\",]|>I?{  . r:z            -2 de inteligencia      \r\n" + //
                    "                1<\"\"\"\"\"\"\"\"\"\"\"\"\":;:[:`^{i t                  \r\n" + //
                    "                z::+:\";([i:,\"\"\"\"\"\"\":Ii,'^~                  \r\n" + //
                    "                 ?-|/1:;[ftt\\)}[]][)\\fi^j                   \r\n" + //
                    "                 \"Bn\\|/[;(tt/tt//t\\/t(,c                    \r\n" + //
                    "                  8c###Wv{_?{]_[??{!I;]!                    \r\n" + //
                    "                 .Mt\\{(uc#MWMW#zWclI^`.                     \r\n" + //
                    "                  uvrzcMz**fzctrM:                          \r\n" + //
                    "                  }*xzM|nx/rj\\z/.                           \r\n" + //
                    "                  *(t\\|jrtccz#|.                            \r\n" + //
                    "                  :#*nucuxfx8:                              \r\n" + //
                    "                  ^vtff|)x#+'                               \r\n" + //
                    "                   [nczuur'                                 \r\n" + //
                    "                   .}uu)");
            System.out.println("                       .\"l~-?_+>iI::^`'..                   \r\n" + //
                    "                 .`,;l~!\"^^^^^^\"\"\"\"\":;l<<~?[?~+~Iii<>       \r\n" + //
                    "          '\";I>+_I,^^^^^^^^^\"\"\"\"\"\"\"\"\"\"\"\"\",:\"\"\"\"\";}n%$.      \r\n" + //
                    "         [W/{_iI,,^^^^^^^^\"\"\"\"\"\"\"\"\"\"\"\"\"\",,\",i}r&B%8B@       \r\n" + //
                    "         x&%%8888%%&zcrf(({]_<<I;:\"\"\"\",l?/*B%888%BB8&:      \r\n" + //
                    "        `r$B%B%8888888888888888%8%%%%BB%888%%B@&*v8},.   Opcion 2      \r\n" + //
                    "       \"%\\(nuW#WB@$$$@BBB%888888&8888%%%B@@8*ncz\\\\*      -10 de hambre  \r\n" + //
                    "        +B8%n/uj\\|nc#Wvnvv*#MW8%%BB@@$BW*r\\M({},^;#^     -6 de diversion    \r\n" + //
                    "         ;vr*$8WM(;^^:)ufrr|tvr\\uzc/}r&WWzc&}?1/xjM@,       \r\n" + //
                    "         .zf+_|xx/|I,:i-(j/rru@B&#M&BBMWWWu_\"?[t&#%%W       \r\n" + //
                    "         `@B&##c\\1{>l+;:+1ff|-_)((}-i<~-]~{|unzB88%*`       \r\n" + //
                    "         `$888%BB@BB%@8cjtr\\}}1)}}+]1?(jn*MBBB%B@/,         \r\n" + //
                    "          '<\\*$B%%88888%BBB@@BMvu\\([<]nB%88%B%|\"            \r\n" + //
                    "               .'^:~}tu*BB@B%%%888%BB%%%B%t!`               \r\n" + //
                    "                          .'`^:l_}\\\\\\\\};` ");
            System.out.println("                                    .....                   \r\n" + //
                    "                              .\"+\\c%88888%Wx1l`             \r\n" + //
                    "                         .;)|f@8M############W%#+.          \r\n" + //
                    "                        \"&ujjfcB&###############&%?.        \r\n" + //
                    "                        (WjfjjfxWBM###############&M`       \r\n" + //
                    "                        |$MfjjjjjnB8###############&$^      \r\n" + //
                    "                       I$M8%nfjjfjt*$8##############&&      \r\n" + //
                    "                       *8##WB&rfjjjjf*B&#############@,     \r\n" + //
                    "                       $W####W@ctfjjjjjM@&###########%<     Opcion 3     \r\n" + //
                    "                       B&######8B*jfrjfjrzB&#########Bl     -3 de hambre \r\n" + //
                    "                       1@########8Bvfjjjjjjz@%M#####M$'     \r\n" + //
                    "                       .W8#########8B*jjjjjffuWB&##M@?      \r\n" + //
                    "                        .z8##########&Bzrfjjjjfjz%%@[       \r\n" + //
                    "                        ^tjBW##########&BWufjjjjjf8-        \r\n" + //
                    "                      `n?'.`/@&##########M%%*rfjfjB^        \r\n" + //
                    "                    ^/-'...ln!:|#%&WMMMMMW&%$vrnx)`         \r\n" + //
                    "                  `n?'...,v:     .`:>____I\"'                \r\n" + //
                    "                ^/-'...ln!                                  \r\n" + //
                    "              `n?'...,v:                                    \r\n" + //
                    "            ^\\-'...!x!.                                     \r\n" + //
                    "          `n?'...,v:                                        \r\n" + //
                    "        ^\\?'...lxi.                                         \r\n" + //
                    "      `n?'...,v:                                            \r\n" + //
                    "     'B'...lni                                              \r\n" + //
                    "     .n]:>u;                                                \r\n" + //
                    "       '`' ");
                    int alimento = x.nextInt();
                    x.nextLine();
                    if(genero == true){
                        if(alimento == 1){
                            System.out.println("FUE ALIMENTADO CON EXITO!");
                            datosniño.get(0).setHambre(datosniño.get(0).getHambre()-5);
                            datosniño.get(0).setInteligencia(datosniño.get(0).getInteligencia()-2);
                        }else if(alimento == 2){
                            System.out.println("FUE ALIMENTADO CON EXITO!");
                            datosniño.get(0).setHambre(datosniño.get(0).getHambre()-10);
                            datosniño.get(0).setDiversion(datosniño.get(0).getDiversion()-6);
                        }else if(alimento == 3){
                            System.out.println("FUE ALIMENTADO CON EXITO!");
                            datosniño.get(0).setHambre(datosniño.get(0).getHambre()-3);
                        }
                    }else if(genero == false){
                        if(alimento == 1){
                            System.out.println("FUE ALIMENTADO CON EXITO!");
                            datosniña.get(0).setHambre(datosniña.get(0).getHambre()-5);
                            datosniña.get(0).setInteligencia(datosniña.get(0).getInteligencia()-2);
                        }else if(alimento == 2){
                            System.out.println("FUE ALIMENTADO CON EXITO!");
                            datosniña.get(0).setHambre(datosniña.get(0).getHambre()-10);
                            datosniña.get(0).setDiversion(datosniña.get(0).getDiversion()-6);
                        }else if(alimento == 3){
                            System.out.println("FUE ALIMENTADO CON EXITO!");
                            datosniña.get(0).setHambre(datosniña.get(0).getHambre()-3);
                        
                    }
             }
    
        } catch (Exception e) {
            e.printStackTrace();
        }
     }
    public void Estado(){
        try {
            String borrar = "Stats.txt";
            BufferedWriter writer = new BufferedWriter(new FileWriter(borrar));
    
            if(genero == true){
                if(datosniño.get(0).getVida() <= 0){
                    System.out.println("SU TAMAGOTCHI A MUERTO");
                    System.out.println("-----💀💀💀💀💀-----");
                    writer.close();               
                }
            }else if(genero == false){
                if(datosniña.get(0).getVida()<=0){
                    System.out.println("SU TAMAGOTCHI A MUERTO");
                    System.out.println("-----💀💀💀💀💀-----");
                    writer.close();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public void Mostrardibujo(){
        if(datosniño.get(0).getGenero() == 2){
            System.out.println("                                         ;.                 \r\n" + //
                    "                                       .}/|`                \r\n" + //
                    "                                      .{////,               \r\n" + //
                    "               .`^\",:;;lllllllllllllll(//////+.             \r\n" + //
                    "         .`,~)//////////////////////////////////?:`         \r\n" + //
                    "       `~//////////////////////////////////////////\\;.      \r\n" + //
                    "     ^[//////////////////////////////////////////////|\"     \r\n" + //
                    "   ']//////////////////////////////////////////////////-.   \r\n" + //
                    "  ^/////////////////////////////////////////////////////}.  \r\n" + //
                    " ^///////////////////////////////////////////////////////+  \r\n" + //
                    ".\\//////////////)}??????????????})\\//////////|////////////' \r\n" + //
                    "{////////?\"`'..................................\"//////////! \r\n" + //
                    "/////////,..........................'^^^`'.....\"//////////| \r\n" + //
                    "/////////\"...^[////]`.............^\\//////[....;//////////| \r\n" + //
                    "/////////^...`-|//1<'..............\";i>i;\"'....i//////////- \r\n" + //
                    "/////////\".....................................i//////////! \r\n" + //
                    "\\////////>..''``^\",,,,\"\"^^^^^^^^^\"\"\"\"^^^^^^``''~//////////, \r\n" + //
                    "I/////////////////////////////////////////////////////////` \r\n" + //
                    "./////////////////////////////////////////////////////////. \r\n" + //
                    " ,///////////////////////////////////////////////////////,  \r\n" + //
                    "  _/////////////////////////////////////////////////////!   \r\n" + //
                    "   ;//////////////////////////////////////////////////1^    \r\n" + //
                    "    .:)////////////////////////////////////////////\\~`      \r\n" + //
                    "       '\"!?)//////////////////////////////////\\]l\"'         \r\n" + //
                    "             .'``````^}////;:/I.[///|^``````'.              \r\n" + //
                    "                   .l\\/////(` .-/////(;.                    \r\n" + //
                    "                 '<///\\////(``(/////\\///?\"                  \r\n" + //
                    "               .~///>.>////}!///////^'<///)`                \r\n" + //
                    "              \"///!.  .[//////////1`   .,[/\\                \r\n" + //
                    "              :!\".      l///~?///I        ..                \r\n" + //
                    "                        ,/// `///^                          \r\n" + //
                    "                        `/// `///'                          \r\n" + //
                    "                        .//? `//1                           \r\n" + //
                    "                         :{' .]]'                           \r\n" + //
                    "                                                            \r\n" + //
                    "");
                    niño.Stadistic();
        }else if(datosniño.get(0).getGenero() == 1){
            System.out.println("                                                            \r\n" + //
                    "                ..                                          \r\n" + //
                    "              ;1?/                           .,!'           \r\n" + //
                    "             |<'^/ `,,`.                    l\\\"(\"           \r\n" + //
                    "             &^''zr;^\"t/.                  !t'')~!~><<^     \r\n" + //
                    "           .^n~\",:\"'+/`   .......          !t'':W^'^}['     \r\n" + //
                    "        <({+,`+{;t',*:--_!I;;;;;Il_~_+i\"'^>11<}~`'\"f.       \r\n" + //
                    "        '[{,'`>_-\"''\"!}<.             'z?,`''v,n:'>1:'      \r\n" + //
                    "          .\"!!(I'`x+<+-x<              .i{+I}-^``\"\"^\">|     \r\n" + //
                    "             .j<^)i    .                  ...*''}_`\":<_     \r\n" + //
                    "            .u!+l' '                         #;(_           \r\n" + //
                    "            (I    ./`      &]I`   >+'..      'lf            \r\n" + //
                    "           '#       >}'    i!.^<~:''>1;'       ~!           \r\n" + //
                    "     ,^    `)         <}^   };   .:]11j\\.       :{>^.       \r\n" + //
                    "      ,{:.i(<  '.`,     \"+<\"';(`'l^v^''''.......  .<z.      \r\n" + //
                    "   `,   'x&!   \"f:M+~i\"'   'l?]*xz|x{nMj|]:''''.  }r` .`,   \r\n" + //
                    "    `??,,u).   `c, uxf?)r,   ..'`:r  />x;l/f''.  l]xf->^.   \r\n" + //
                    "       ,(u*,   .{l {^r-;1\\       '>|`;-[}ix\\'.   \"M1        \r\n" + //
                    "       .|,       ^)!v}*ct'       .'`-[zc#j<`''   ^n>!liI    \r\n" + //
                    "         ,}:.      '^^`.     \">' .'''''...''''.  .r'        \r\n" + //
                    "           '>}i`          \"-]:.~_}`           .`-]'         \r\n" + //
                    "              .^;!ll!:\"'.            .'`,!_{/v&v;'          \r\n" + //
                    "                      .\"u&MzvxxxuzW&&M##********#Mz]`       \r\n" + //
                    "                       `*&&M#**#MW&&&&W#************W1      \r\n" + //
                    "                      `W&&&&cjzWW\\/&&&&f>1uMMM#MMM#j]`      \r\n" + //
                    "                      u&&&u-nMW1)#u&,#&&,   ....,?}^        \r\n" + //
                    "                     ^&&xcu&M})W&tnW^\"&&*      `j`M+,`      \r\n" + //
                    "                     ^v-'&u[{WMr1Mu*/.\"]`   <\\+?l`1>tt`     \r\n" + //
                    "                        'cfjM*r#&Wz#f:illI!;<]{(^``u,       \r\n" + //
                    "                          l&**WM*#j.^!il!Illii1W_j>[M^      \r\n" + //
                    "                           ;&W&&WW'            `'           \r\n" + //
                    "                            ^u&&t'                          \r\n" + //
                    "                              ..                            \r\n" + //
                    "");
                    niña.Stadistic();
        }
    }
}