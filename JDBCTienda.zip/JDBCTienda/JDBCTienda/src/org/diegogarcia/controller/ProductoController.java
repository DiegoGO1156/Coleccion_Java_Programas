package org.diegogarcia.controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import org.diegogarcia.dao.Conexion;
import org.diegogarcia.model.Cliente;
import org.diegogarcia.model.Producto; 

public class ProductoController {
    private static Connection conexion = null;
    private static PreparedStatement statement = null;
    private static ResultSet resultSet = null;
    
    private static ProductoController instance;
    
    private ProductoController(){

    }

    public static ProductoController getInstace(){
        if(instance == null){
            instance = new ProductoController();
        }
        return instance;
    }

    public void agregarProducto(String descripcion, String numeroExistencias, String precio){
        try {
            conexion = Conexion.getIstance().obtenerConexion();
            String sql = "CALL sp_AgregarProductos(?,?,?)";
            statement = conexion.prepareStatement(sql);
            statement.setString(1, descripcion);
            statement.setString(2, numeroExistencias);
            statement.setString(3, precio);
            statement.execute();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally{
            try {
                if(statement != null){
                    statement.close();
                }
                if(conexion != null){
                    //conexion.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

    }

    public ArrayList <Producto> listarProductos(){
        
        ArrayList<Producto> productos = new ArrayList<>();

        try {
            conexion = Conexion.getIstance().obtenerConexion();
            String sql = "Call sp_ListarProductos()";
            statement = conexion.prepareStatement(sql);
            resultSet = statement.executeQuery();
            

            while(resultSet.next()){
                String descripcion = resultSet.getString("descripcion");
                String numeroExistencias = resultSet.getString("numeroExistencias");
                String precio = resultSet.getString("precio");
                productos.add(new Producto(descripcion, numeroExistencias, precio));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if(resultSet != null){
                    resultSet.close();
                }
                if(statement != null){
                    statement.close();
                }
                if(conexion != null){
                    //conexion.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        return productos;
        
    }

    public void eliminarProductos(int prodId){
        try {
            conexion = Conexion .getIstance().obtenerConexion();
            String sql = "Call sp_EliminarProductos(?)";
            statement = conexion.prepareStatement(sql);
            statement.setInt(1, prodId);
            statement.execute();

        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            try {
                if(statement != null){
                    statement.close();
                }
                if(conexion != null){
                   //conexion.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    public Producto buscarProducto(int prodId){
        Producto producto = null;
        try {
            conexion = Conexion.getIstance().obtenerConexion();
            String sql = "Call sp_BuscarProducto(?)";
            statement = conexion.prepareStatement(sql);
            statement.setInt(1, prodId);
            resultSet = statement.executeQuery();

            if(resultSet.next()){
                String descripcion = resultSet.getString("descripcion");
                String numeroExistencias = resultSet.getString("numeroExistencias");
                String precio = resultSet.getString("precio");
                producto = new Producto(descripcion, numeroExistencias, precio);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if(resultSet != null){
                    resultSet.close();
                }
                if(statement != null){
                    statement.close();
                }
                if(conexion != null){
                    //conexion.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return producto;
    }

    public void editarProducto(int prodId, String des, String numExis, String pre){
        try {
            conexion = Conexion.getIstance().obtenerConexion();
            String sql = "Call sp_EditarClientes(?, ?, ?, ?)";
            statement = conexion.prepareStatement(sql);
            statement.setInt(1, prodId);
            statement.setString(2, des);
            statement.setString(3, numExis);
            statement.setString(4, pre);
            statement.execute();
            
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if(statement != null){
                    statement.close();
                }
                if(conexion != null){
                    //conexion.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
