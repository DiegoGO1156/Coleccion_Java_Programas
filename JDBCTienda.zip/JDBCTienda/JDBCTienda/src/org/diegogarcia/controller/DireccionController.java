package org.diegogarcia.controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import org.diegogarcia.dao.Conexion;
import org.diegogarcia.model.Direccion;

public class DireccionController {

    private static DireccionController instance;

    private static Connection conexion = null;
    private static PreparedStatement statement = null;
    private static ResultSet resultSet = null;

    private DireccionController(){

    }
    public static DireccionController getInstance(){
        if(instance == null){
            instance = new DireccionController();
        }
        return instance;
    }


    public void agregarDireccion(String avenida, String calle, String zona, String numCasa, int provinciaId){
        try {
            conexion = Conexion.getIstance().obtenerConexion();
            String sql = "Call sp_AgregarDireccion(?, ?, ?, ?)";
            statement = conexion.prepareStatement(sql);
            statement.setString(1, avenida);
            statement.setString(2, calle);
            statement.setString(3, zona);
            statement.setString(4, numCasa);
            statement.setInt(5, provinciaId);
            statement.execute();

        } catch (SQLException e) {
            e.printStackTrace();
        } finally{ 
            try {
                if(statement != null){
                    statement.close();
                }
                if(conexion != null){
                    conexion.close();
                }
                
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    public ArrayList <Direccion> listarDirecciones(){
        ArrayList <Direccion> direcciones = new ArrayList<>();
        try {
            conexion = Conexion.getIstance().obtenerConexion();
            String sql = "sp_ListarDirecciones";
            statement = conexion.prepareStatement(sql);
            resultSet = statement.executeQuery();

            while(resultSet.next()){
                int direccionId = resultSet.getInt("direccionId");
                String avenida = resultSet.getString("avenida");
                String calle = resultSet.getString("calle");
                String zona = resultSet.getString("zona");
                String numCasa = resultSet.getString("numCasa");
                int provinciaId = resultSet.getInt("provinciaId");

                direcciones.add(new Direccion(direccionId, avenida, calle, zona, numCasa, provinciaId));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            try {
                if(statement != null){
                    statement.close();
                }
                if(resultSet != null){
                    resultSet.close();
                }
                if(conexion != null){
                    conexion.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return direcciones;
    }

    public void eliminarDirecciones(int dirId){
        try {
           conexion = Conexion.getIstance().obtenerConexion();
           String sql = "Call sp_EliminarDirecciones(?)";
           statement = conexion.prepareStatement(sql);
           statement.setInt(1, dirId);
           statement.execute(); 
        } catch (SQLException e) {
           e.printStackTrace();
        } finally {
            try {
                if(statement != null){
                    statement.close();
                }
                if(conexion != null){
                    conexion.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    public Direccion buscarDireccion(int dirId){
        Direccion direccion = null;
        try {
            conexion = Conexion.getIstance().obtenerConexion();
            String sql = "sp_BuscarDirecciones(?)";
            statement = conexion.prepareStatement(sql);
            statement.setInt(1, dirId);
            resultSet = statement.executeQuery();

            if(resultSet.next()){
                String avenida = resultSet.getString("avenida");
                String calle = resultSet.getString("calle");
                String zona = resultSet.getString("zona");
                String numCasa = resultSet.getString("numCasa");
                direccion = new Direccion(avenida, calle, zona, numCasa);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if(statement != null){
                statement.close();
                }
                if(resultSet != null){
                    resultSet.close();
                }
                if(conexion != null){
                    conexion.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return direccion;
    }

    public void editarDireccion(int dirId, String ave, String cal, String zon, String numCa, int proId){
        try {
            conexion = Conexion.getIstance().obtenerConexion();
            String sql = "sp_EditarDirecciones(?, ?, ?, ?, ?, ?)";
            statement = conexion.prepareStatement(sql);
            statement.setInt(1, dirId);
            statement.setString(2, ave);
            statement.setString(3, cal);
            statement.setString(4, zon);
            statement.setString(5, numCa);
            statement.setInt(6, proId);
            statement.execute();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally{ 
            try {
                if(statement != null){
                    statement.close();
                }
                if(conexion != null){
                    conexion.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
    
}
