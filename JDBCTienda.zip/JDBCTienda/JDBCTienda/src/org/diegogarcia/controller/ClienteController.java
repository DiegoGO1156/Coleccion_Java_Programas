package org.diegogarcia.controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import org.diegogarcia.dao.Conexion;
import org.diegogarcia.model.Cliente; 

public class ClienteController {

    private static Connection conexion = null;
    private static PreparedStatement statement = null;
    private static ResultSet resultSet = null;
    
    private static ClienteController instance;
    
    private ClienteController(){

    }

    public static ClienteController getInstace(){
        if(instance == null){
            instance = new ClienteController();
        }
        return instance;
    }

    public void agregarCliente(String nombre, String apellido, String numTelefono, int direccionId){
        try {
            conexion = Conexion.getIstance().obtenerConexion();
            String sql = "CALL sp_AgregarCliente(?,?,?,?)";
            statement = conexion.prepareStatement(sql);
            statement.setString(1, nombre);
            statement.setString(2, apellido);
            statement.setString(3, numTelefono);
            statement.setInt(4, direccionId);
            statement.execute();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally{
            try {
                if(statement != null){
                    statement.close();
                }
                if(conexion != null){
                    //conexion.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

    }

    public ArrayList <Cliente> listarClientes(){
        
        ArrayList<Cliente> clientes = new ArrayList<>();

        try {
            conexion = Conexion.getIstance().obtenerConexion();
            String sql = "Call sp_ListarClientes()";
            statement = conexion.prepareStatement(sql);
            resultSet = statement.executeQuery();
            

            while(resultSet.next()){
                int clienteId = resultSet.getInt("clienteId");
                String nombre = resultSet.getString("nombre");
                String apellido = resultSet.getString("apellido");
                String telefono = resultSet.getString("numTelefono");
                int direccionId = resultSet.getInt("direccionId");
                clientes.add(new Cliente(clienteId, nombre, apellido, telefono, direccionId));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if(resultSet != null){
                    resultSet.close();
                }
                if(statement != null){
                    statement.close();
                }
                if(conexion != null){
                    //conexion.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        return clientes;
        
    }

    public void eliminarCliente(int cliId){
        try {
            conexion = Conexion .getIstance().obtenerConexion();
            String sql = "Call sp_EliminarClientes(?)";
            statement = conexion.prepareStatement(sql);
            statement.setInt(1, cliId);
            statement.execute();

        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            try {
                if(statement != null){
                    statement.close();
                }
                if(conexion != null){
                   //conexion.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    public Cliente buscarCliente(int cliId){
        Cliente cliente = null;
        try {
            conexion = Conexion.getIstance().obtenerConexion();
            String sql = "Call sp_BuscarClientes(?)";
            statement = conexion.prepareStatement(sql);
            statement.setInt(1, cliId);
            resultSet = statement.executeQuery();

            if(resultSet.next()){
                String nombre = resultSet.getString("nombre");
                String apellido = resultSet.getString("apellido");
                String numTelefono = resultSet.getString("numTelefono");
                cliente = new Cliente(nombre, apellido, numTelefono);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if(resultSet != null){
                    resultSet.close();
                }
                if(statement != null){
                    statement.close();
                }
                if(conexion != null){
                    //conexion.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return cliente;
    }

    public void editarCliente(int cliId, String nom, String ape, String numTel, int dirId){
        try {
            conexion = Conexion.getIstance().obtenerConexion();
            String sql = "Call sp_EditarClientes(?, ?, ?, ?, ?)";
            statement = conexion.prepareStatement(sql);
            statement.setInt(1, cliId);
            statement.setString(2, nom);
            statement.setString(3, ape);
            statement.setString(4, numTel);
            statement.setInt(5, dirId);
            statement.execute();
            
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if(statement != null){
                    statement.close();
                }
                if(conexion != null){
                    //conexion.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
