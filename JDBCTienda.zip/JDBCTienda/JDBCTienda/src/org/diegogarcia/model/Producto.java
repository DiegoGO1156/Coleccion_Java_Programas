package org.diegogarcia.model;

public class Producto {

    private String descripcion;
    private String numeroExistecias;
    private String precio; 

    public Producto(){

    }

    public Producto(String descripcion, String numeroExistecias, String precio) {
        this.descripcion = descripcion;
        this.numeroExistecias = numeroExistecias;
        this.precio = precio;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getNumeroExistecias() {
        return numeroExistecias;
    }

    public void setNumeroExistecias(String numeroExistecias) {
        this.numeroExistecias = numeroExistecias;
    }

    public String getPrecio() {
        return precio;
    }

    public void setPrecio(String precio) {
        this.precio = precio;
    }

    @Override
    public String toString() {
        return "{" + "\n" +
        "   Descripcion:"+ descripcion + "\n"+
        "   Numero De Existencias:"+ numeroExistecias + "\n"+
        "   Precio:"+ precio + "\n"+

        "}";
    }
    
    
}
