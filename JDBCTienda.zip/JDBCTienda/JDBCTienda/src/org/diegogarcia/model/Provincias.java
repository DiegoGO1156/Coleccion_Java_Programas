package org.diegogarcia.model;

public class Provincias {

    private int provinciaId;
    private String nombreProvincia;
    
    public Provincias(){

    }

    public Provincias(int provinciaId, String nombreProvincia) {
        this.provinciaId = provinciaId;
        this.nombreProvincia = nombreProvincia;
    }

    public int getProvinciaId() {
        return provinciaId;
    }

    public void setProvinciaId(int provinciaId) {
        this.provinciaId = provinciaId;
    }

    public String getNombreProvincia() {
        return nombreProvincia;
    }

    public void setNombreProvincia(String nombreProvincia) {
        this.nombreProvincia = nombreProvincia;
    }
    
    
    
}
