package org.diegogarcia.model;

public class Direccion {
    private int direccionId;
    private String avenida;
    private String calle;
    private String zona;
    private String numCasa;
    private int provinciaId;

    public Direccion(){

    }

    public Direccion(int direccionId, String avenida, String calle, String zona, String numCasa, int provinciaId) {
        this.direccionId = direccionId;
        this.avenida = avenida;
        this.calle = calle;
        this.zona = zona;
        this.numCasa = numCasa;
        this.provinciaId = provinciaId;
    }

    public Direccion(String avenida, String calle, String zona, String numCasa) {
        this.avenida = avenida;
        this.calle = calle;
        this.zona = zona;
        this.numCasa = numCasa;
    }

    public int getDireccionId() {
        return direccionId;
    }

    public String getAvenida() {
        return avenida;
    }

    public String getCalle() {
        return calle;
    }

    public String getZona() {
        return zona;
    }

    public String getNumCasa() {
        return numCasa;
    }

    public int getProvinciaId() {
        return provinciaId;
    }

    public void setDireccionId(int direccionId) {
        this.direccionId = direccionId;
    }

    public void setAvenida(String avenida) {
        this.avenida = avenida;
    }

    public void setCalle(String calle) {
        this.calle = calle;
    }

    public void setZona(String zona) {
        this.zona = zona;
    }

    public void setNumCasa(String numCasa) {
        this.numCasa = numCasa;
    }

    public void setProvinciaId(int provinciaId) {
        this.provinciaId = provinciaId;
    }

    @Override
    public String toString() {
        return "{" + "\n" +
        "   DireccionID:"+ direccionId + "\n"+
        "   Avenida:"+ avenida + "\n"+
        "   Calle:"+ calle + "\n"+
        "   Zona:"+ zona + "\n" +
        "   Numero de casa:"+ numCasa + "\n"+ 
        "   ProvinciaID:" + provinciaId+ "\n"+

        "}";
    }

    
    
    
}
