package org.diegogarcia.model;

public class Cliente {
    private int clienteId;
    private String nombre;
    private String apellido;
    private String numTelefono;
    private int direccionId;

    public Cliente(){
        
    }

    public Cliente(int clienteId, String nombre, String apellido, String numTelefono, int direccionId) {
        this.clienteId = clienteId;
        this.nombre = nombre;
        this.apellido = apellido;
        this.numTelefono = numTelefono;
        this.direccionId = direccionId;
    }

    
    public Cliente(String nombre, String apellido, String numTelefono) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.numTelefono = numTelefono;
    }



    public int getClienteId() {
        return clienteId;
    }
    public void setClienteId(int clienteId) {
        this.clienteId = clienteId;
    }
    public String getNombre() {
        return nombre;
    }
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    public String getApellido() {
        return apellido;
    }
    public void setApellido(String apellido) {
        this.apellido = apellido;
    }
    public String getNumTelefono() {
        return numTelefono;
    }
    public void setNumTelefono(String numTelefono) {
        this.numTelefono = numTelefono;
    }
    public int getDireccionId() {
        return direccionId;
    }
    public void setDireccionId(int direccionId) {
        this.direccionId = direccionId;
    }

    @Override
    public String toString() {
        return "{" + "\n" +
        "   ClienteID:"+ clienteId + "\n"+
        "   Nombre:"+ nombre + "\n"+
        "   Apellido:"+ apellido + "\n" +
        "   Telefono:"+ numTelefono + "\n"+ 
        "   DireccionID:" + direccionId+ "\n"+

        "}";
    }
    
    
}
