package org.diegogarcia.system;

import org.diegogarcia.view.ClienteControllerView;

public class Main {
    public static void main(String[] args) throws Exception {
        ClienteControllerView.getInstance().menuClienteView();
    }
}
