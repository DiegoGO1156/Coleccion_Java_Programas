package org.diegogarcia.view;

import java.util.ArrayList;
import java.util.Scanner;

import org.diegogarcia.controller.DireccionController;
import org.diegogarcia.controller.ProductoController;
import org.diegogarcia.model.Direccion;
import org.diegogarcia.model.Producto;

public class ProductoControllerView {


    Scanner s = new Scanner(System.in);

    private static ProductoControllerView instance;
    
    private ProductoControllerView(){

    }

    public static ProductoControllerView getInstance(){
        if(instance == null){
            instance = new ProductoControllerView();
        }
        return instance; 
    }

    public void menuProductoView(){
        int a = 1;
        while(a == 1){
            System.out.println("============== BIENVENIDO AL MENU DE PRODUCTOS ==============");
            System.out.println("Escoja una opcion");
            System.out.println("1. Agregar Producto");
            System.out.println("2. Listar Producto");
            System.out.println("3. Editar Producto");
            System.out.println("4. Eliminar Producto");
            System.out.println("5. Buscar Producto");
            System.out.println("7. Salir al Menu principal");
            int menu = s.nextInt();
            s.nextLine();
                switch(menu){
                    case 1:
                    agregarProducto();
                    break;
                    case 2:
                    listarProductos();
                    break;
                    case 3:
                    editarProducto();
                    break;
                    case 4:
                    eliminarProductos();
                    break;
                    case 5:
                    buscarProductos();
                    break;
                    default:
                    System.out.println("=======================================");
                    System.out.println("================ ERROR ================");
                    System.out.println("=======================================");
                    System.out.println("============Opcion No Valida===========");
                    break;
                }
        }
    }

    public void agregarProducto(){
        System.out.println("============== MENU AGREGAR DIRECCION ==============");
        System.out.println("Ingrese la Descripcion del producto");
        String descripcion = s.nextLine();
        System.out.println("Ingrese la cantidad de existencias");
        String numeroExistencias = s.nextLine();
        System.out.println("Ingrese el precio del Producto");
        String precio = s.nextLine();
        s.nextLine();

        ProductoController.getInstace().agregarProducto(descripcion, numeroExistencias, precio);

        System.out.println("LOS DATOS FUERON AGREGADOS CON EXITO!");
    }

    public void listarProductos(){
        ArrayList<Producto> productos = ProductoController.getInstace().listarProductos();
        for(Producto producto: productos){
            System.out.println(producto.toString());
        }
    }
    
    public void eliminarProductos(){
        System.out.println("==============  MENU ELIMINAR PRODUCTOS ==============");
        System.out.println("Ingrese el ID del Producto que desea eliminar");
        int prodId = s.nextInt();
        s.nextLine();

        ProductoController.getInstace().eliminarProductos(prodId);
        
        System.out.println("EL PRODUCTO FUE ELIMINADO CON EXITO!");
    }

    public void buscarProductos(){
        System.out.println("============== MENU BUSCAR PRODUCTOS ==============");
        System.out.println("Ingrese el ID del Producto que quiere buscar");
        int prodId = s.nextInt();
        s.nextLine();

        Producto producto = ProductoController.getInstace().buscarProducto(prodId);

        System.out.println(producto.toString());
        System.out.println("EL PRODUCTO FUE ENCONTRADA CON EXITO!");

    }
    
    public void editarProducto(){
        System.out.println("============== MENU EDITAR PRODUCTO ==============");
        System.out.println("Ingrese el ID del Producto que desea Editar");
        int prodId = s.nextInt();
        s.nextLine();
        System.out.println("Ingrese la nueva Descripcion de Producto");
        String des = s.nextLine();
        System.out.println("Ingrese el nuevo numero de Existencias del Producto ");
        String numExis = s.nextLine();
        System.out.println("Ingrese el nuevo precio del Producto");
        String pre = s.nextLine();

        ProductoController.getInstace().editarProducto(prodId, des, numExis, pre);

        System.out.println("LOS DATOS DE LA DIRECCION FUERON EDITADOS CON EXITO!");
    } 
    
}
