package org.diegogarcia.view;

import java.util.ArrayList;
import java.util.Scanner;

import org.diegogarcia.controller.DireccionController;
import org.diegogarcia.model.Direccion;

public class DireccionControllerView {

    Scanner s = new Scanner(System.in);

    private static DireccionControllerView instance;
    
    private DireccionControllerView(){

    }

    public static DireccionControllerView getInstance(){
        if(instance == null){
            instance = new DireccionControllerView();
        }
        return instance;
    }

    public void menuDireccionView(){
        int a = 1;
        while(a == 1){
            System.out.println("============== BIENVENIDO AL MENU DE DIRECCIONES ==============");
            System.out.println("Escoja una opcion");
            System.out.println("1. Agregar Direccion");
            System.out.println("2. Listar Direccion");
            System.out.println("3. Editar Direccion");
            System.out.println("4. Eliminar Direccion");
            System.out.println("5. Buscar Direccion");
            System.out.println("7. Salir al Menu principal");
            int menu = s.nextInt();
            s.nextLine();
                switch(menu){
                    case 1:
                    agregarDireccion();
                    break;
                    case 2:
                    listarDirecciones();
                    break;
                    case 3:
                    editarDirecciones();
                    break;
                    case 4:
                    eliminarDireccionesView();
                    break;
                    case 5:
                    buscarDirecciones();
                    break;
                    default:
                    System.out.println("=======================================");
                    System.out.println("================ ERROR ================");
                    System.out.println("=======================================");
                    System.out.println("============Opcion No Valida===========");
                    break;
                }
        }
    }

    public void agregarDireccion(){
        System.out.println("============== MENU AGREGAR DIRECCION ==============");
        System.out.println("Ingrese la Avenida");
        String avenida = s.nextLine();
        System.out.println("Ingrese la calle");
        String calle = s.nextLine();
        System.out.println("Ingrese la zona");
        String zona = s.nextLine();
        System.out.println("Ingrese el numero de casa");
        String numeroCasa = s.nextLine();
        System.out.println("Ingrese el Id de la Provincia");
        int proviciaId = s.nextInt();
        s.nextLine();

        DireccionController.getInstance().agregarDireccion(avenida, calle, zona, numeroCasa, proviciaId);

        System.out.println("LOS DATOS FUERON AGREGADOS CON EXITO!");
    }

    public void listarDirecciones(){
        ArrayList<Direccion> direcciones = DireccionController.getInstance().listarDirecciones();
        for(Direccion direccion: direcciones){
            System.out.println(direccion.toString());
        }
    }
    
    public void eliminarDireccionesView(){
        System.out.println("==============  MENU ELIMINAR DIRECCIONES ==============");
        System.out.println("Ingrese el ID de la Direccion que desea eliminar");
        int dirId = s.nextInt();
        s.nextLine();

        DireccionController.getInstance().eliminarDirecciones(dirId);
        
        System.out.println("LA DIRECCION FUE ELIMINADA CON EXITO!");
    }

    public void buscarDirecciones(){
        System.out.println("============== MENU BUSCAR DIRECCIONES ==============");
        System.out.println("Ingrese el ID de la Direccion que quiere buscar");
        int dirId = s.nextInt();
        s.nextLine();

        Direccion direccion = DireccionController.getInstance().buscarDireccion(dirId);

        System.out.println(direccion.toString());
        System.out.println("LA DIRECCIÓN FUE ENCONTRADA CON EXITO!");

    }
    
    public void editarDirecciones(){
        System.out.println("============== MENU EDITAR DIRECCIONES ==============");
        System.out.println("Ingrese el ID de la Direccion que desea Editar");
        int dirId = s.nextInt();
        s.nextLine();
        System.out.println("Ingrese la nueva Avenida");
        String ave = s.nextLine();
        System.out.println("Ingrese la nueva Calle");
        String cal = s.nextLine();
        System.out.println("Ingrese la nueva Zona");
        String zon = s.nextLine();
        System.out.println("Ingrese el nuevo numero de Casa");
        String numCa = s.nextLine();
        System.out.println("Ingrese la nueva ID de Provincia");
        int proId = s.nextInt();
        s.nextLine();

        DireccionController.getInstance().editarDireccion(dirId, ave, cal, zon, numCa, proId);

        System.out.println("LOS DATOS DE LA DIRECCION FUERON EDITADOS CON EXITO!");
    }
    
}
