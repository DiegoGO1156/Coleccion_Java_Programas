package org.diegogarcia.view;

import java.util.ArrayList;
import java.util.Scanner;

import org.diegogarcia.controller.ClienteController;
import org.diegogarcia.model.Cliente;

public class ClienteControllerView {

    Scanner x = new Scanner(System.in);
    

    private static ClienteControllerView  instance;

    private ClienteControllerView(){

    }

    public static ClienteControllerView getInstance(){
        if(instance == null){
            instance = new ClienteControllerView();
        }
        return instance;
    }

    public void menuClienteView(){
        int a = 1;
        while(a == 1){
            System.out.println("=========== BIENVENIDO AL MENU ===========");
            System.out.println("Escoja una opción");
            System.out.println("1. Agregar Cliente");
            System.out.println("2. Listar Clientes");
            System.out.println("3. Editar Cliente");
            System.out.println("4. Eliminar Cliente");
            System.out.println("5. Buscar Cliente");
            System.out.println("7. Salir al Menu Principal");
            int menu = x.nextInt();
            x.nextLine();

            switch(menu){
                case 1:
                agregarClienteView();
                break;
                case 2:
                listarClientesView();
                break;
                case 3:
                editarClienteView();
                break;
                case 4:
                eliminarClienteView();
                break;
                case 5:
                buscarClienteView();
                break;
                case 7:
                System.out.println("HASTA PRONTO!");
                a = 2;
                break;
                default:
                System.out.println("=======================================");
                System.out.println("================ ERROR ================");
                System.out.println("=======================================");
                System.out.println("============Opcion No Valida===========");
                break;
            }
        }
    }

    public void agregarClienteView(){
        System.out.println("========== MENU AGREGAR CLIENTE ==========");
        System.out.println("Ingrese el nombre del cliente");
        String nombre = x.nextLine();
        System.out.println("Ingrese el apellido del Cliente");
        String apellido = x.nextLine();
        System.out.println("Ingrese el numero del cliente");
        String numerocliente = x.nextLine();
        System.out.println("Ingrese la direccion ID");
        int direccionId = x.nextInt();
        x.nextLine();

        ClienteController.getInstace().agregarCliente(nombre, apellido, numerocliente, direccionId);
        System.out.println("LOS DATOS FUERON AGREGADOS CON EXITO!");
    }
    
    public void listarClientesView(){
        ArrayList<Cliente> clientes = ClienteController.getInstace().listarClientes();

        for(Cliente cliente: clientes) {
            System.out.println(cliente.toString());
        }
    }

    public void eliminarClienteView(){
        System.out.println("========= MENU ELIMINAR CLIENTES =========");
        System.out.println("Ingrese el ID del cliente que desea eliminar");
        int cliId = x.nextInt();
        x.nextLine();

        ClienteController.getInstace().eliminarCliente(cliId);

        System.out.println("EL CLIENTE FUE ELIMINADO CON EXITO!");
    }

    public void buscarClienteView(){
        System.out.println("========= MENU BUSCAR CLIENTE =========");
        System.out.println("Ingrese el ID del cliente que desea buscar");
        int cliId = x.nextInt();
        x.nextLine();

        Cliente cliente =  ClienteController.getInstace().buscarCliente(cliId);

        System.out.println(cliente.toString());
        System.out.println("EL CLIENTE FUE ENCONTRADO CON EXITO!");
    }
    public void editarClienteView(){
        System.out.println("============= MENU EDITAR CLIENTE =============");
        System.out.println("Ingrese el ID del cliente que desea editar");
        int cliId = x.nextInt();
        x.nextLine();
        System.out.println("Ingrese el nuevo nombre del cliente");
        String nom = x.nextLine();
        System.out.println("Ingrese el nuevo apellido del Cliente");
        String ape = x.nextLine();
        System.out.println("Ingrese el nuevo numero del cliente");
        String numTel = x.nextLine();
        System.out.println("Ingrese la nueva direccion ID");
        int dirId = x.nextInt();
        x.nextLine();

        ClienteController.getInstace().editarCliente(cliId, nom, ape, numTel, dirId);

        System.out.println("LOS DATOS DEL CLIENTE FUERON EDITADOS CON EXITO!");
    }
    
}
